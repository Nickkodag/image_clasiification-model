Build an ML classifier to classify each card from the deck of 52 cards.
Training data is provided in the train folder with 52 images, each image representing 1 category from the deck of 52 cards. The category label  is represented by the name of the file.
Kindly note that there is very little data to learn from, so we expect you to perform  data augmentation techniques to create synthetic data for training the model.
As part of submission, your task is
1) To run the inference on the images in the test folder and prepare a CSV file with 3 columns, imageFileName,predictedLabel,predictedProb
sampleSubmission.csv is provided for reference
2) 1 pager approach document describing the methodology, challenges and stuff you couldn't try because of time or any other constraints.
3) The complete code base [a zip file or a drive link]
The solution would be evaluated based on the accuracy of the classification algorithm and quality of code and the approach document.
Kindly note that this data is not for distribution, so make sure not to copy it on any cloud or open source platforms.

